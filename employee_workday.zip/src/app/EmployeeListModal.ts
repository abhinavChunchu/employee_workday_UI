export interface EmployeeListModal {
  employeeId: string;
  vacationDays: number;
  employeeType: string;
  workingDays: number;
}
